These free files are made by pixaroma.com

If you agree to use our website, then you have accepted to abide by all the rules and regulations, Terms and conditions that govern www.pixaroma.com which are subjected to change from time to time as we deem fit.

LICENSE for all the Graphics from Freebies Section Only:

   - You�re free to download, modify and use our graphics for your personal and commercial projects BUT you can�t Sell or Redistribute them as standalone files.
   
   - You can use these graphics on websites, blogs, printed on business cards, mugs or t-shirts, for facebook pages or any other custom work!
 
   - No any attribution or link back to Pixaroma is need.

You�re not allowed to:

Resell, sub-license, license or redistribute these graphics to third parties. 
You can�t sell these at sites like graphicriver/creativemarket/shutterstock/society6 or use these graphics for unlawful purposes, to infringe upon any copyright, to violate any person/identity or any other purpose that is not legal.
You can�t use our graphics for company logo design (Because every logo should be unique).

SHARING!

You are free to share our resources by making a link to the particular page at our website. You are not allowed to make a direct link for download!

SUPPORT:
No support is offered by pixaroma.com for Freebies - but you can leave a message if you have any questions. We offer these graphics �as is�.

Where you can find us:

http://pixaroma.com/

https://www.facebook.com/pixaroma
https://www.youtube.com/c/PixaromaDesign
https://twitter.com/pixaroma
https://www.instagram.com/pixaroma/
https://plus.google.com/+PixaromaDesign

https://dribbble.com/pixaroma
https://www.behance.net/pixaroma

https://creativemarket.com/pixaroma
https://designbundles.net/pixaroma
https://thehungryjpeg.com/pixaroma/
https://www.shutterstock.com/g/pixaroma
https://www.fotolia.com/p/205455232