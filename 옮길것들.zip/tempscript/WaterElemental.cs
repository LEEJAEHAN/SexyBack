﻿//using System;
//using UnityEngine;

//namespace SexyBackPlayScene
//{
//    internal class WaterElemental : Elemental
//    {
//        public WaterElemental() : base()
//        {
//            string name = "waterball";
//            ShooterName = "shooter_" + name;
//            ProjectilePrefabName = "prefabs/" + name;
//            ProjectileReadyStateName = name + "_spot";
//        }
//    }
//}