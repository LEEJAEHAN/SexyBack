﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace SexyBackPlayScene
{
    class TestTapController
    {
        List<GameObject> aPrefabs;
        List<GameObject> bPrefabs;

        GameObject aPrefab;
        GameObject bPrefab;

        GameObject grid;
        GameObject grid_disable;

        public TestTapController()
        {
            grid = GameObject.Find("Item_Enable");
            grid.transform.DestroyChildren();

            grid_disable = GameObject.Find("Item_Disable");


            aPrefabs = new List<GameObject>();
            bPrefabs = new List<GameObject>();

            aPrefab = Resources.Load<GameObject>("Prefabs/UI/ablock") as GameObject;
            bPrefab = Resources.Load<GameObject>("Prefabs/UI/bblock") as GameObject;

            FillAList();
            FillBList();

        }

        void FillAList()
        {
            // 게임로직에서 호출이있을때만 ( 변화가생겼다는것 ) 동작
            // 모듈로부터 데이터를 가져와 리스트를갱신
            // 지금은 임시

            for (int i = 0; i < 3; i++)
            {
                GameObject temp = GameObject.Instantiate<GameObject>(aPrefab) as GameObject;
                temp.SetActive(true);
                aPrefabs.Add(temp);
            }
        }

        void FillBList()
        {

            for (int i = 0; i < 4; i++)
            {
                GameObject temp = GameObject.Instantiate<GameObject>(bPrefab) as GameObject;
                temp.SetActive(false);
                bPrefabs.Add(temp);
            }


        }


        public void noticeTapChanged(string sendername, bool toggle)
        {
            // 지금형식은 버튼이름에따라 다른 kind의 item만 추가할뿐, 나머지 동작은 같다;
            // 자 그럼 이걸
            if (sendername == "TapButton1")
            {
                foreach (GameObject a in aPrefabs)
                {
                    if (toggle)
                    {
                        a.SetActive(true);
                        a.transform.parent = grid.transform;
                        a.transform.localScale = grid.transform.localScale;
                    }
                    else // untoggle
                    {
                        a.transform.parent = grid_disable.transform;
                        a.transform.localScale = grid.transform.localScale;
                        a.SetActive(false);
                        //  InfoClear();
                    }
                }
            }
            if (sendername == "TapButton2")
            {
                foreach (GameObject b in bPrefabs)
                {
                    if (toggle)
                    {
                        b.SetActive(true);
                        b.transform.parent = grid.transform;
                        b.transform.localScale = grid.transform.localScale;
                    }
                    else // untoggle
                    {
                        b.transform.parent = grid_disable.transform;
                        b.transform.localScale = grid.transform.localScale;
                        b.SetActive(false);
                        //InfoClear();
                    }
                }
            }

            grid.GetComponent<UIGrid>().Reposition();
        }


    }

}
