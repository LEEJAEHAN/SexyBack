﻿//using System;
//using UnityEngine;

//namespace SexyBackPlayScene
//{
//    internal class IceElemental : Elemental
//    {
//        public IceElemental() : base()
//        {
//            string name = "iceblock";
//            ShooterName = "shooter_" + name;
//            ProjectilePrefabName = "prefabs/" + name;
//            ProjectileReadyStateName = name + "_spot";
//        }
//    }
//}