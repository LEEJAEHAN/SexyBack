﻿//using System;
//using UnityEngine;

//namespace SexyBackPlayScene
//{
//    internal class ElectricElemental : Elemental
//    {
//        public ElectricElemental() : base()
//        {
//            string name = "electricball";
//            ShooterName = "shooter_" + name;
//            ProjectilePrefabName = "prefabs/" + name;
//            ProjectileReadyStateName = name + "_spot";
//        }
//    }
//}