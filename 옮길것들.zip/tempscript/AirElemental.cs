﻿//using System;
//using UnityEngine;

//namespace SexyBackPlayScene
//{
//    internal class AirElemental : Elemental
//    {
//        public AirElemental(string shooterName, ElementalData proj) : base(shooterName, proj)
//        {
//            string name = "airball";
//            ShooterName = "shooter_" + name;
//            ProjectilePrefabName = "prefabs/"+ name;
//            ProjectileReadyStateName = name + "_spot";


//            //this.
//        }
//    }
//}